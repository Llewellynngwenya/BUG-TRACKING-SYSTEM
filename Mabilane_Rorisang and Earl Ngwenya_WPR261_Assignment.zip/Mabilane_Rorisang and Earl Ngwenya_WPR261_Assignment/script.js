var selectedRow = null;

// Show Alerts
function showAlert(message, className){
const div = document.createElement('div');
div. className = 'alert alert-${c1assName}' ;

div.appendChild(document.createTextNode( message)) ;
const container = document.querySe1ector(".container");
const main = document.querySe1ector(".main");
container.insertBefore(div, main);

setTimeout(() => document. querySe1ector('.alert").remove(),3000);
}

// Clear All Fields
function clearFields() {
const issueID = document.querySelector("#issueID").value = "";
const issueTitle = document.querySelector("#issueTitle").value = "";
const issueDiscription = document.querySelector("#issueDiscription").value = "";
const assignee = document.querySelector("#assignee").value = "";

//Add data
document.querySelectorAll("#issue-form").addEventListener("submit", (e) => {
    e.preventDefault();

// Get Form values
function clearFields() {
document.querySelector("#issueID").value;
document.querySelector("#issueTitle").value;
document.querySelector("#issueDiscription").value;
document.querySelector("#assignee").value;
});

// validate
    if(issueID =="" || issueTitle =="" || issueDiscription =="" || assignee ==""){
    showA1ert("P1ease fill in all fields", "danger");
    }
    else{
        if(selectedRow == null){
        const list = document. querySeIector(#issue-list");
        const row = document.createComment("tr");

        row.innerHTML = '
            <td>${issueID}</td>
             <td>${issueTitle}</td>
             <td>${issueDiscription}</td>
             <td>${assignee}</td>
            '
        }    

// Edit Data
document. querySe1ector ( "#issue- list " ) . addEventListener( " click " ,
- e. target;
if(target . classList. contains ( "edit" ) ) {
selectedRow = target. parentE1ement.parentE1ement;
document. querySe1ector( "#firstName '
= selectedRow.chi1dren[e] . textContent;
. value
document. querySe1ector( "#firstName '
= selectedRow.chi1dren[1] .textContent;
• value
document. rstName'
'j•value = selectedRow.chi1dren[2] .textContent;

// Delete Data
"#student -1i s t" ) . addEventListener( "cl ick" ,
target
z e. target;
target. classList. contains( "delete " ) ) {
target. parentE1ement. parent Element. remove( ) ;
showA1ert( "Student Data Deleted", "danger");
});